/*!
 * Minimal Mistakes Jekyll Theme 4.27.3 by Michael Rose
 * Copyright 2013-2025 Michael Rose - mademistakes.com | @mmistakes
 * Free for personal and commercial use under the MIT license
 * https://github.com/mmistakes/minimal-mistakes/blob/master/LICENSE
 */
